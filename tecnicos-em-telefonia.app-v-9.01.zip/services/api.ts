import { Client, ServiceOrder, User, Quote, Product, MaintenanceContract } from '../types';
import { db } from './mockDb';

const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// This file now simulates a network API using the local mock database.
// All functions are async to mimic network latency.

const login = async (username?: string, password?: string): Promise<User> => {
    await delay(500); // Simulate network roundtrip
    const { user, error } = db.findUserByCredentials(username, password);
    if (error) {
        // In a real app, this would be a 401 or similar.
        throw new Error(error);
    }
    if (!user) {
        // Should not happen with mock data, but good practice.
        throw new Error("User not found");
    }
    return user;
};

const getServiceOrders = async (): Promise<ServiceOrder[]> => {
    await delay(300);
    return db.getServiceOrders();
};

const addServiceOrder = async (order: Omit<ServiceOrder, 'id' | 'clientName' | 'status' | 'serviceOrderNumber'>): Promise<ServiceOrder> => {
    await delay(400);
    const result = db.addServiceOrder(order);
    if (result.error) throw new Error(result.error);
    return result.order!;
};

const updateServiceOrder = async (order: ServiceOrder): Promise<ServiceOrder> => {
    await delay(400);
    return db.updateServiceOrder(order);
};

const getClients = async (): Promise<Client[]> => {
    await delay(300);
    return db.getClients();
};

const addClient = async (client: Omit<Client, 'id'>): Promise<Client> => {
    await delay(400);
    return db.addClient(client);
};

const getUsers = async (): Promise<User[]> => {
    await delay(300);
    return db.getUsers();
};

const addUser = async (user: Omit<User, 'id' | 'status'> & { password?: string }): Promise<User> => {
    await delay(400);
    return db.addUser(user);
};

const getProducts = async (): Promise<Product[]> => {
    await delay(300);
    return db.getProducts();
};

const addProduct = async (product: Omit<Product, 'id'>): Promise<Product> => {
    await delay(400);
    return db.addProduct(product);
};

const getQuotes = async (): Promise<Quote[]> => {
    await delay(300);
    return db.getQuotes();
};

const addQuote = async (quote: Omit<Quote, 'id' | 'clientName' | 'quoteNumber' | 'status'>): Promise<Quote> => {
    await delay(400);
    const result = db.addQuote(quote);
    if (result.error) throw new Error(result.error);
    return result.quote!;
};

const updateQuote = async (quote: Quote): Promise<Quote> => {
    await delay(400);
    return db.updateQuote(quote);
};


const getMaintenanceContracts = async (): Promise<MaintenanceContract[]> => {
    await delay(300);
    return db.getMaintenanceContracts();
};

const addMaintenanceContract = async (contract: Omit<MaintenanceContract, 'id' | 'clientName' | 'status' | 'contractNumber'>): Promise<MaintenanceContract> => {
    await delay(400);
    const result = db.addMaintenanceContract(contract);
    if (result.error) throw new Error(result.error);
    return result.contract!;
};

export const api = {
    login,
    getClients,
    addClient,
    getServiceOrders,
    addServiceOrder,
    updateServiceOrder,
    getUsers,
    addUser,
    getProducts,
    addProduct,
    getQuotes,
    addQuote,
    updateQuote,
    getMaintenanceContracts,
    addMaintenanceContract,
};