// Este arquivo não é mais necessário.
// Os dados da aplicação agora são fornecidos pelo servidor de backend.
